window.WORMGPT_API = '';
